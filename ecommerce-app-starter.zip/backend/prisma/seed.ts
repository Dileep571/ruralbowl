import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  await prisma.product.createMany({
    data: [
      { name: "Apples", price: 2.5, description: "Fresh red apples" },
      { name: "Bananas", price: 1.2, description: "Organic bananas" },
      { name: "Carrots", price: 1.8, description: "Crunchy carrots" },
    ],
  });
}

main().catch(e => {
  console.error(e);
  process.exit(1);
});